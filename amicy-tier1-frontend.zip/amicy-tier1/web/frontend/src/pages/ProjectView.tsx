import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api, Project } from "../api/client";
import TodoList from "../components/TodoList";
import NotesPane from "../components/NotesPane";
import Canvas from "../components/Canvas";
import Spinner from "../components/Spinner";

type PanelTab = "notes" | "todo";

const STATUSES = ["active", "blocked", "backlog", "done"] as const;

const PIN_COLOR: Record<string, string> = {
  active:  "var(--pin-active)",
  blocked: "var(--pin-blocked)",
  backlog: "var(--pin-backlog)",
  done:    "var(--pin-done)",
};

export default function ProjectView() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [project, setProject] = useState<Project | null>(null);
  const [tab, setTab] = useState<PanelTab>("notes");
  const [error, setError] = useState<string | null>(null);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [newTag, setNewTag] = useState("");
  const [addingTag, setAddingTag] = useState(false);
  const tagInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!slug) return;
    api.getProject(slug).then(setProject).catch((e) => setError(e.message));
  }, [slug]);

  useEffect(() => {
    if (addingTag) tagInputRef.current?.focus();
  }, [addingTag]);

  const persist = async (updated: Project) => {
    try {
      await api.updateProject(updated);
      setProject(updated);
    } catch (e: any) {
      setError(e.message);
    }
  };

  const handleDelete = async () => {
    if (!slug) return;
    await api.deleteProject(slug);
    navigate("/");
  };

  const handleAddTag = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!project || !newTag.trim()) return;
    const tag = newTag.trim();
    if (!project.tags.includes(tag)) {
      await persist({ ...project, tags: [...project.tags, tag] });
    }
    setNewTag("");
    setAddingTag(false);
  };

  if (!slug) return null;
  if (error)
    return (
      <div style={{ padding: 24, fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--pin-blocked)" }}>
        error: {error}
      </div>
    );
  if (!project)
    return (
      <div style={{ padding: 24 }}>
        <Spinner label="loading project" />
      </div>
    );

  const deadlineValue = project.deadline ? project.deadline.slice(0, 10) : "";

  return (
    <div className="project-layout">
      {/* ── Sidebar ─────────────────────────────────────────────────────── */}
      <aside className="project-sidebar">
        <Link to="/" className="sidebar-back">
          ← board
        </Link>

        {/* Name */}
        <div>
          <div className="sidebar-name">{project.name}</div>
          {project.summary && (
            <div className="sidebar-summary" style={{ marginTop: 6 }}>
              {project.summary}
            </div>
          )}
        </div>

        {/* Status */}
        <div>
          <div className="sidebar-section-label">status</div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span
              className="sidebar-status-dot"
              style={{ background: PIN_COLOR[project.status] ?? "var(--pin-backlog)" }}
            />
            <select
              className="sidebar-select"
              value={project.status}
              onChange={(e) => persist({ ...project, status: e.target.value })}
            >
              {STATUSES.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Deadline */}
        <div>
          <div className="sidebar-section-label">deadline</div>
          <input
            type="date"
            className="sidebar-date-input"
            value={deadlineValue}
            onChange={(e) =>
              persist({
                ...project,
                deadline: e.target.value ? new Date(e.target.value).toISOString() : null,
              })
            }
          />
        </div>

        {/* Tags */}
        <div>
          <div className="sidebar-section-label">tags</div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
            {project.tags.map((tag) => (
              <span key={tag} className="sidebar-tag">
                {tag}
                <button
                  className="sidebar-tag-remove"
                  onClick={() => persist({ ...project, tags: project.tags.filter((t) => t !== tag) })}
                >
                  ×
                </button>
              </span>
            ))}

            {!addingTag ? (
              <button className="sidebar-add-tag-btn" onClick={() => setAddingTag(true)}>
                + tag
              </button>
            ) : (
              <form onSubmit={handleAddTag} style={{ display: "inline-flex" }}>
                <input
                  ref={tagInputRef}
                  value={newTag}
                  onChange={(e) => setNewTag(e.target.value)}
                  onBlur={() => !newTag && setAddingTag(false)}
                  onKeyDown={(e) => e.key === "Escape" && setAddingTag(false)}
                  className="field-input"
                  style={{ width: 80, padding: "2px 6px", fontSize: 11 }}
                  placeholder="tag"
                />
              </form>
            )}
          </div>
        </div>

        {/* Spacer pushes delete to bottom */}
        <div style={{ flex: 1 }} />

        {/* Delete */}
        {!confirmingDelete ? (
          <button className="sidebar-delete-btn" onClick={() => setConfirmingDelete(true)}>
            delete project
          </button>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
            <button
              className="sidebar-delete-btn confirm"
              onClick={handleDelete}
            >
              confirm delete
            </button>
            <button className="sidebar-delete-btn" onClick={() => setConfirmingDelete(false)}>
              cancel
            </button>
          </div>
        )}
      </aside>

      {/* ── Notes / Todo panel ───────────────────────────────────────────── */}
      <div className="project-panel">
        <div className="project-panel-tabs">
          {(["notes", "todo"] as PanelTab[]).map((t) => (
            <button
              key={t}
              className={`project-panel-tab${tab === t ? " active" : ""}`}
              onClick={() => setTab(t)}
            >
              {t}
            </button>
          ))}
        </div>
        <div className="project-panel-body">
          {tab === "notes" && <NotesPane slug={slug} />}
          {tab === "todo"  && <TodoList  slug={slug} />}
        </div>
      </div>

      {/* ── Canvas pane ──────────────────────────────────────────────────── */}
      <div className="project-canvas-pane">
        <Canvas slug={slug} />
      </div>
    </div>
  );
}
