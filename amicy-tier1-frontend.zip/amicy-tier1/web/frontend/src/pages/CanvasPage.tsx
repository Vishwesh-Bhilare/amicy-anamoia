import { useCallback, useEffect, useRef, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Tldraw, Editor, getSnapshot, loadSnapshot } from "tldraw";
import "tldraw/tldraw.css";
import { api } from "../api/client";

const SAVE_DEBOUNCE_MS = 1000;

export default function CanvasPage() {
  const { slug } = useParams<{ slug: string }>();
  const editorRef = useRef<Editor | null>(null);
  const saveTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "saving" | "saved" | "error">("loading");

  // Escape key → back to project
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        window.location.href = `/project/${slug}`;
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [slug]);

  useEffect(() => {
    return () => {
      if (saveTimeout.current) clearTimeout(saveTimeout.current);
    };
  }, []);

  const handleMount = useCallback(
    (editor: Editor) => {
      editorRef.current = editor;
      editor.user.updateUserPreferences({ colorScheme: "dark" });

      if (!slug) return;

      api
        .getCanvas(slug)
        .then((data) => {
          if (data && data.document) loadSnapshot(editor.store, data);
          setStatus("ready");
        })
        .catch(() => setStatus("ready"));

      const unsubscribe = editor.store.listen(
        () => {
          setStatus("saving");
          if (saveTimeout.current) clearTimeout(saveTimeout.current);
          saveTimeout.current = setTimeout(async () => {
            try {
              const snapshot = getSnapshot(editor.store);
              await api.saveCanvas(slug!, snapshot);
              setStatus("saved");
            } catch {
              setStatus("error");
            }
          }, SAVE_DEBOUNCE_MS);
        },
        { source: "user", scope: "document" }
      );

      return () => unsubscribe();
    },
    [slug]
  );

  if (!slug) return null;

  return (
    <div className="canvas-fullscreen-page">
      {/* Minimal HUD — top-left so it doesn't fight tldraw's own UI */}
      <div className="canvas-fullscreen-bar">
        <Link
          to={`/project/${slug}`}
          className="canvas-hud-btn"
          style={{ textDecoration: "none" }}
          title="Back to project (Esc)"
        >
          ← {slug}
        </Link>
        <SaveDot status={status} />
      </div>

      {/* tldraw fills the rest */}
      <div style={{ flex: 1, position: "relative" }}>
        <Tldraw onMount={handleMount} />
      </div>
    </div>
  );
}

function SaveDot({ status }: { status: string }) {
  const label: Record<string, string> = {
    loading: "loading",
    ready: "ready",
    saving: "saving…",
    saved: "saved",
    error: "save failed",
  };
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 6,
        fontFamily: "var(--font-mono)",
        fontSize: 10,
        color: "var(--ink-faint)",
        background: "var(--card-bg)",
        border: "0.5px solid var(--card-border)",
        borderRadius: 3,
        padding: "4px 10px",
      }}
    >
      <span className="save-dot" data-status={status} />
      {label[status]}
    </div>
  );
}
