import { useEffect, useRef, useState } from "react";
import { api } from "../api/client";
import Spinner from "./Spinner";
import { renderInlineMarkdown } from "./markdown";

export default function NotesPane({ slug }: { slug: string }) {
  const [content, setContent] = useState("");
  const [draft, setDraft] = useState("");
  const [loading, setLoading] = useState(true);
  const [posting, setPosting] = useState(false);
  const [focused, setFocused] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const load = () => {
    api.getNotes(slug).then((r) => setContent(r.content)).finally(() => setLoading(false));
  };

  useEffect(load, [slug]);

  // 'n' focuses the editor when not already typing
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const typing = target.tagName === "INPUT" || target.tagName === "TEXTAREA";
      if (e.key === "n" && !typing) {
        e.preventDefault();
        textareaRef.current?.focus();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  const handleSubmit = async () => {
    const text = draft.trim();
    if (!text || posting) return;
    setPosting(true);
    try {
      await api.logNote(slug, text);
      setDraft("");
      setFocused(false);
      load();
    } finally {
      setPosting(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // Cmd+Enter or Ctrl+Enter to submit
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleSubmit();
    }
    // Escape clears and unfocuses
    if (e.key === "Escape") {
      setDraft("");
      setFocused(false);
      textareaRef.current?.blur();
    }
  };

  const handleCancel = () => {
    setDraft("");
    setFocused(false);
    textareaRef.current?.blur();
  };

  if (loading) return <Spinner label="loading notes" />;

  const entries = content
    .split(/\n---\n/)
    .map((e) => e.trim())
    .filter(Boolean);

  return (
    <div>
      {/* Editor */}
      <div className="notes-editor-wrap">
        <textarea
          ref={textareaRef}
          className="notes-textarea"
          placeholder={"log an entry… (⌘↵ to save, Esc to cancel)\n\n**bold**, `code`, [links](url) supported"}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onFocus={() => setFocused(true)}
          onKeyDown={handleKeyDown}
          rows={focused ? 5 : 2}
          style={{ transition: "height 0.15s" }}
        />
        {(focused || draft) && (
          <div className="notes-submit-row">
            <button className="notes-cancel-btn" onClick={handleCancel} type="button">
              cancel
            </button>
            <button
              className="notes-submit-btn"
              onClick={handleSubmit}
              disabled={posting || !draft.trim()}
              type="button"
            >
              {posting ? "…" : "log  ⌘↵"}
            </button>
          </div>
        )}
      </div>

      {/* Entries */}
      {entries.length === 0 && (
        <p style={{ color: "var(--ink-faint)", fontFamily: "var(--font-mono)", fontSize: 12, lineHeight: 1.6 }}>
          Nothing logged yet — first entry starts the log.
        </p>
      )}

      <div>
        {entries
          .slice()
          .reverse()
          .map((entry, i) => {
            const [firstLine, ...rest] = entry.split("\n");
            const tsMatch = firstLine.match(/\*\*(.+?)\*\*/);
            const timestamp = tsMatch ? tsMatch[1] : firstLine;
            const body = tsMatch ? rest.join("\n").trim() : entry;

            return (
              <div key={i} className="notes-entry">
                <div className="notes-entry-ts">{timestamp}</div>
                {body && (
                  <div className="notes-entry-body">
                    {renderInlineMarkdown(body)}
                  </div>
                )}
              </div>
            );
          })}
      </div>
    </div>
  );
}
