import { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Tldraw, Editor, getSnapshot, loadSnapshot } from "tldraw";
import "tldraw/tldraw.css";
import { api } from "../api/client";

const SAVE_DEBOUNCE_MS = 1000;

interface CanvasProps {
  slug: string;
}

export default function Canvas({ slug }: CanvasProps) {
  const editorRef = useRef<Editor | null>(null);
  const saveTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "saving" | "saved" | "error">("loading");
  const [gridMode, setGridMode] = useState(false);

  const applyGridMode = useCallback((on: boolean) => {
    editorRef.current?.updateInstanceState({ isGridMode: on });
  }, []);

  const handleMount = useCallback(
    (editor: Editor) => {
      editorRef.current = editor;
      editor.user.updateUserPreferences({ colorScheme: "dark" });

      api
        .getCanvas(slug)
        .then((data) => {
          if (data && data.document) loadSnapshot(editor.store, data);
          setStatus("ready");
        })
        .catch(() => setStatus("ready"));

      const unsubscribe = editor.store.listen(
        () => {
          setStatus("saving");
          if (saveTimeout.current) clearTimeout(saveTimeout.current);
          saveTimeout.current = setTimeout(async () => {
            try {
              const snapshot = getSnapshot(editor.store);
              await api.saveCanvas(slug, snapshot);
              setStatus("saved");
            } catch {
              setStatus("error");
            }
          }, SAVE_DEBOUNCE_MS);
        },
        { source: "user", scope: "document" }
      );

      return () => unsubscribe();
    },
    [slug]
  );

  useEffect(() => {
    return () => {
      if (saveTimeout.current) clearTimeout(saveTimeout.current);
    };
  }, []);

  const handleToggleGrid = () => {
    const next = !gridMode;
    setGridMode(next);
    applyGridMode(next);
  };

  return (
    <div className="canvas-wrap">
      {/* HUD */}
      <div className="canvas-hud">
        <button
          onClick={handleToggleGrid}
          className={`canvas-hud-btn${gridMode ? " active" : ""}`}
          title={gridMode ? "Grid snap on — click to disable" : "Enable grid snap"}
        >
          {gridMode ? "⊞ snap" : "⊟ snap"}
        </button>

        {/* Fullscreen / open in dedicated page */}
        <Link
          to={`/project/${slug}/canvas`}
          className="canvas-hud-btn"
          style={{ textDecoration: "none" }}
          title="Open canvas fullscreen (⤢)"
        >
          ⤢
        </Link>

        <SaveDot status={status} />
      </div>

      {/* tldraw fills the pane — parent (.project-canvas-pane) is flex col */}
      <div style={{ position: "absolute", inset: 0 }}>
        <Tldraw onMount={handleMount} />
      </div>
    </div>
  );
}

function SaveDot({ status }: { status: string }) {
  const titles: Record<string, string> = {
    loading: "Loading canvas…",
    ready:   "Canvas ready",
    saving:  "Saving…",
    saved:   "Saved",
    error:   "Save failed — check your connection",
  };
  return (
    <div
      title={titles[status]}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 5,
        background: "var(--card-bg)",
        border: "0.5px solid var(--card-border)",
        borderRadius: 3,
        padding: "4px 8px",
        fontFamily: "var(--font-mono)",
        fontSize: 10,
        color: "var(--ink-faint)",
      }}
    >
      <span className="save-dot" data-status={status} />
      {status === "error" ? "failed" : status === "saving" ? "saving" : status === "saved" ? "saved" : ""}
    </div>
  );
}
